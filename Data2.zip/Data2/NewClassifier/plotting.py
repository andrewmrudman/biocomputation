import numpy as np
import matplotlib.pyplot as plt

def live_plot(a, b, c , axar ,delay = True):
    y1 = []

    if (a != b):

        if (a < b):
            y1 = list(range(a, b + 1))

        else:
            y1 = list(range(a, b - 1, -1))

    else:
        y1 = list(10 * [b])

    x1 = list(np.linspace(c*10 - 10, c*10, num=len(y1)))
    axar.plot(x1, y1, '-')
    if delay:
        plt.pause(0.5)





def setup_common_subplots(nrows=1,ncols=1 ,xlabel="X label",ylabel="Y label",title=" Title "):

    f, axarr = plt.subplots()
    # nrows, ncols, sharex = False, sharey = False
    # axarr = np.array(axarr)
    #axarr = np.rot90(axarr,3)
    #axarr = np.flip(axarr,1)
    #axarr = axarr.ravel()
    f.suptitle(title, fontsize=14)
    f.text(0.5, 0.02, xlabel, ha='center')
    f.text(0.03, 0.5, ylabel, va='center', rotation='vertical')

    return f,axarr

