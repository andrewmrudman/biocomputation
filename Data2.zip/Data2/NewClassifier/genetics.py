import numpy as np
import copy
import plotting as pt
import matplotlib.pyplot as plt


class Population:
    def __init__(self, mutation_rate=0.001,no_rules =10,inputs=[],outputs=[],pool_size=10, generate=False):

        self.average_fitness = 0
        # self.prev_top_rule_set = None
        self.top_rule_set = None  #previous top rule

        self.POOL_SIZE = pool_size
        self.rule_sets = [None]*no_rules
        self.no_rules = no_rules
        self.inputs = inputs
        self.outputs = outputs
        self.GENOME_LENGTH = no_rules*(len(inputs[0])+1)

        # self.MUTATION_RATE = 0.02
        self.MUTATION_RATE = 1/self.GENOME_LENGTH + 0.005     # self.MUTATION_RATE = 0.05
        self.fitness_history = [] #used for graphing the top fitness history
        self.average_history = [] #used for graphing the average fitness history
        self.generations = 1
        self.total_fitness = 0

        if generate:
            self.generate()
            self.evaluate_fitness(official=False)
            self.prev_top_rule_set = copy.deepcopy(self.top_rule_set)
            self.fitness_history.append(0)
            self.average_history.append(0)

    # roulette selection
    def start_roulette(self):

        index = int(np.argmax([x.fitness for x in self.rule_sets]))
        print(f"index :{index}")
        self.prev_top_rule_set = copy.deepcopy(self.rule_sets[index])
        temp = []

        running_total = 0
        print("Total fitness : "+ str(self.total_fitness))


        for x in range(self.POOL_SIZE):

            a=[]
            for b in range(2):
                point_p = np.random.randint(self.total_fitness)
                print("point  : " + str(point_p))
                running_total = 0
                i = 0
                while running_total < point_p:
                    running_total += self.rule_sets[i].fitness
                    i +=1

                i -=1
                a.append(self.rule_sets[i])

            temp.append(copy.deepcopy(a[0] if (a[0].fitness > a[1].fitness) else a[1]))
        print("\n\n\n")
        self.rule_sets.clear()
        self.rule_sets = temp

    # tournament selection
    def start_tournament(self):
        # get index of top rule and make a copy
        index = int(np.argmax([x.fitness for x in self.rule_sets]))
        self.prev_top_rule_set = copy.deepcopy(self.rule_sets[index])
        temp = []

        for b in range(self.POOL_SIZE):
            a = (self.rule_sets[np.random.randint(self.POOL_SIZE)])
            c = (self.rule_sets[np.random.randint(self.POOL_SIZE)])

            temp.append(copy.deepcopy(a if (a.fitness > c.fitness) else c))

        self.rule_sets.clear()
        self.rule_sets = temp

    # replace worst individual in population with previous best one
    def replace_worst(self):
        index = int(np.argmin([x.fitness for x in self.rule_sets]))
        self.rule_sets[index] = copy.deepcopy(self.prev_top_rule_set)
    # one point crossover
    def cross_over(self):

        for index in range(0, self.POOL_SIZE, 2):
            cross_point = np.random.randint(self.GENOME_LENGTH)
            a = self.rule_sets[index]
            b = self.rule_sets[index + 1]
            a.genome[cross_point:], b.genome[cross_point:] = b.genome[cross_point:], a.genome[cross_point:]


    def mutate(self):
        for x in range(self.POOL_SIZE):
            self.rule_sets[x].mutate(mutation_rate=self.MUTATION_RATE)

    # evaluates fitness of whole entire popuilation
    def evaluate_fitness(self, official=True):
        self.calc_rules()   # convert genome into a list of Rule Objects

        self.total_fitness = 0
        for x in self.rule_sets:

            x.evaluate_fitness(inputs=self.inputs,outputs=self.outputs)
            self.total_fitness +=x.fitness

        # get top individual
        top = int(np.argmax([x.fitness for x in self.rule_sets]))

        self.top_rule_set = self.rule_sets[top]
        self.average_fitness = sum(x.fitness / self.POOL_SIZE for x in self.rule_sets)

        if official == True:
            self.generations += 1
            # add fitness data to fitness history arrays
            self.fitness_history.append(self.prev_top_rule_set.fitness if self.prev_top_rule_set.fitness > self.top_rule_set.fitness else self.top_rule_set.fitness )
            self.average_history.append(int(self.average_fitness))
            # self.print()



    def calc_rules(self):
        for x in self.rule_sets:
            x.calc_rules()
    # generate population
    def generate(self):

        self.rule_sets[:] = (RuleSet(no_rules=self.no_rules ,no_inputs=len(self.inputs[0]),no_outputs=1) for x in range(self.POOL_SIZE))


    def print(self):
        print("----------Population---------------")
        for x in self.rule_sets:

            x.print()

        if self.prev_top_rule_set.fitness> self.prev_top_rule_set.fitness :
            self.prev_top_rule_set.print()
        else:
            self.top_rule_set.print()


        print(f"Average Fitness : {self.average_fitness}   Top Fitness : {self.top_rule_set.fitness if self.top_rule_set.fitness> self.prev_top_rule_set.fitness else self.prev_top_rule_set.fitness}  Generation { self.generations} ")


    def graph_next_point(self):

        if hasattr(self, 'axarr') == False:
            #print("dfgfdgfdgfdgfdgdfgdfgdfgdfgdfgdfgdfgdfgdfg")
            self.f, self.axarr = pt.setup_common_subplots(1, 1, xlabel="Generation",
                                                                ylabel="Fitness Level",
                                                                title="Fitness Vs Generation Using ")


        self.axarr.set_ylim(0, len(self.inputs))
        pt.live_plot(self.fitness_history[-2], self.fitness_history[-1],
                           len(self.fitness_history) - 1, self.axarr)
        pt.live_plot(self.average_history[-2], self.average_history[-1],
                           len(self.average_history) - 1, self.axarr)


    def graph_fitness_history(self):

        if hasattr(self, 'axarr1') == False:
            #print("dfgfdgfdgfdgfdgdfgdfgdfgdfgdfgdfgdfgdfgdfg")
            self.f1, self.axarr1 = pt.setup_common_subplots(1, 1, xlabel="Generation",
                                                                ylabel="Fitness Level",
                                                                title="Fitness Vs Generation Using ")

        self.axarr1.set_ylim(0, len(self.inputs))
        x = list(range(0, len(self.fitness_history)))
        print(f"{len(x)}   {len(self.fitness_history)}")
        self.axarr1.plot(x , self.fitness_history)
        self.axarr1.plot(x, self.average_history)

class RuleSet:

    def __init__(self, no_rules=10, no_inputs=5, no_outputs=1, label=1, generate=True):


        self.fitness = 0

        self.rules = no_rules * [None]

        self.no_rules = no_rules
        self.input_bits = no_inputs
        self.output_bits = no_outputs
        self.rule_bits = self.input_bits + self.output_bits
        self.genome_length = self.no_rules * self.rule_bits

        self.genome = [None] * self.genome_length
        self.rule_set_label = label

        if generate:
           self.generate()

    def generate(self):
        self.genome[:] = (np.random.randint(2) if (x + 1) % (self.rule_bits) == 0 else np.random.randint(3) for x in
                          range(len(self.genome)))



    def evaluate_fitness(self, inputs, outputs,prints=False):

        sum_ = 0

        for x in range(len(inputs)):
            solved_output = self.look_up_rule(inputs[x],prints=prints)

            if solved_output == None:
                fitness = 0
            else:
                fitness = 1 if (solved_output == outputs[x]) else 0

            sum_ += fitness

        self.fitness = sum_

    #  look for rule in rule list  that corresponds with data input
    def look_up_rule(self, input,prints=False):
        for x in self.rules:
            correct = 0

            for v in range(self.input_bits):

                if (x.cmd[v] != 2) and (x.cmd[v] != input[v]):

                    break

                else:
                    correct += 1

            if correct == self.input_bits:
                if(prints):
                    x.print()
                return x.output[0]

        return None

    # mutate specific genome
    def mutate(self, mutation_rate=0.1):

        valid =[ [1,2] , [0,2], [0,1]]

        for i in range(len(self.genome)):
            if np.random.uniform() < mutation_rate:
                if  (i + 1) % (self.rule_bits) == 0:
                    self.genome[i]= valid[self.genome[i]][0]
                else:
                    self.genome[i] = valid[self.genome[i]][np.random.randint(2)]



    # convert genome to list of rules
    def calc_rules(self):
        self.rules =[]
        rule_bits = self.output_bits + self.input_bits
        genome_length = rule_bits * self.no_rules
        j = 0
        for i in range((self.no_rules)):

            cmd = self.genome[j:j+self.input_bits]
            j+=self.input_bits
            out =self.genome[j:j+self.output_bits]
            j += self.output_bits
            rule = RuleSet.Rule(cmd=cmd,output=out)
            self.rules.append(rule)

    def print(self):
        print(f"{self.genome}  Fitness : {self.fitness}")

    def print_rule(self):
        for x in self.rules:
            x.print()

        print(f"Fitness :{self.fitness}")

    class Rule:

        def __init__(self, cmd=[], output=None):
            self.cmd = cmd
            self.output = output
        def print(self):

            print(f"{self.cmd} {self.output}")

