import genetics as gn
import numpy as np
import copy
import matplotlib.pyplot as plt

# read in data file and initialize input and ouitput arrays
text_file = open("data2.txt", "r")
array = text_file.read().splitlines()
inputs = list((x.split(" ")[0] for x in array))
inputs = list(list(map(int, x)) for x in inputs)
outputs = list(map(int,list((x.split(" ")[1] for x in array))))

# initialize coutner and avergae variables
iterations = 10
average_gen =0
ac =0
i = 0

# declare arrays being used to capture to store fitness histories of population per iteration
actual_top =[]
actual_average=[]
while i < iterations:

    # generate population and initialize with starting values
    population = gn.Population(no_rules=6, inputs=inputs, outputs=outputs, pool_size=50, generate=True)
    # loop until model is fully trained or population has reached max number of generations ( 1500 )
    while population.top_rule_set.fitness < len(inputs) and population.generations < 1500:

        population.start_tournament()
        population.cross_over()
        population.mutate()
        population.evaluate_fitness()
        population.replace_worst()

        # uncomment to see fitness plotted in real time
        # population.graph_next_point()

    # uncomment if you wish to see full average and top history displayed in a graph
    # population.graph_fitness_history()

    print(f" current top : {population.top_rule_set.fitness}  generation: {population.generations}")
    if(top>population.generations):
        top=population.generations
    population.top_rule_set.print_rule()

    # add number of generations to average counter
    average_gen +=population.generations
    ac +=1

    # add top fitness history to array
    actual_top.append(copy.deepcopy(population.fitness_history))
    # add average fitness to array
    actual_average.append(copy.deepcopy(population.average_history))

    plt.show()

    i+=1

#     calculate average
average_gen /=ac
new_top= []
new_average= []




# normalize data onto the same axis ( change all scales to average generation length and then work out average of average fitness and top fitness over the iterations per generations
for i in range(int(average_gen)):
    sumT = 0
    sumA = 0
    for j in range(iterations):

        index = int(round(((i+1)/average_gen)* len(actual_top[j])))
        sumT += actual_top[j][index-1]
        sumA += actual_average[j][index-1]

    sumT = sumT/iterations
    sumA = sumA / iterations
    new_top.append(sumT)
    new_average.append(sumA)


# not very important just filling up the best performers array with max fitness to be the same length as average generations , so that it can be plotte don same axis.
length = list([len(x) for x in actual_top]) # getting list of lengths of top fitness paths
index = int(np.argmin([x for x in length]))
new_top_route = copy.deepcopy(actual_top[index]) # making copy of best route with quickest generations
fill_top = list([64.0] * (int(average_gen) - length[index])) #filling the top pathway so that it has same length as the averagegenerations
new_top_route.extend(fill_top)

# writing data to csv file
x =np.array(list([x for x in range(int(average_gen))]))
output = np.column_stack((x.flatten(),np.array(new_top).flatten(), np.array(new_average).flatten(), np.array(new_top_route).flatten()))
np.savetxt("DATA2/3rdTestPS(50)NR(20)extra0.005.csv",output,delimiter=',',header="x,y1,y2,top",fmt='%f',comments='')






































# file = open("DATA1/20RULES/PS(50)MUT(1G)NR(32/averagegenerations.txt", "w")
# average /=ac
# file.write(f"average generations {average}")
# file.close()


# x =np.array(list([x for x in range(0 , len(population.fitness_history))]))
# #
# output = np.column_stack((x.flatten(),np.array(population.fitness_history).flatten(), np.array(population.average_history).flatten()))
#
# # np.savetxt("data.csv",output,delimiter=',',header="x,y1",comments='')

# np.savetxt(f"DATA1/20RULES/PS(50)MUT(1G)NR(32/output-ng-{population.generations}-Data2-{i+1}-fit-{population.top_rule_set.fitness}.csv",output,delimiter=',',header="x,y1,y2",comments='')


# if counter ==50:
    #     population.check_status()
    #     print("----------Rules are just in wrong order----------------")
    #     h = input("sdfg")
    #     k=1
    #
    # if(k):
    #
    #
    #     population.mutate1()
    #
    # else:

