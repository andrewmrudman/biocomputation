import genetics as gn
import numpy as np
import copy
import matplotlib.pyplot as plt

# read in data file and initialize input and ouitput arrays
text_file = open("data3.txt", "r")
array = text_file.read().splitlines()
inputs = list((x.split(" ")[0:-1] for x in array))
inputs = list(list(map(float, x)) for x in inputs)
outputs = list(map(int,list((x.split(" ")[-1] for x in array))))

# generate and initialize population
population = gn.Population(no_rules=20, inputs=inputs, outputs=outputs, pool_size=50, generate=True, training=0.5)



while population.valid_history[-1] < 800:

    population.start_tournament()

    population.cross_over()

    population.mutate()

    population.evaluate_fitness()

    population.replace_worst()

    # uncomment to see live plotting
    # population.graph_next_point()

    # every 10 generations do validation test of top RUleset
    if(population.generations%10 == 0 ):
        population.validate()
        print(f" current top : {population.prev_top_rule_set.fitness}  generation: {population.generations}  validity: {population.valid_history[-1]}")


x =np.array(list([x for x in range(0 , len(population.fitness_history))]))

output = np.column_stack((x.flatten(),(np.array(population.fitness_history)/(len(population.inputs))).flatten(), (np.array(population.average_history)/(len(population.inputs))).flatten(),(np.array(population.valid_history)/(len(population.validate_inputs))).flatten()))

np.savetxt("data80.csv",output,delimiter=',',header="x,top,average,valid",fmt='%f',comments='')

print(f" current top : {population.top_rule_set.fitness}  generation: {population.generations}")














