import numpy as np
import copy
import plotting as pt
import matplotlib.pyplot as plt


class Population:
    def __init__(self, mutation_rate=0.001, no_rules=10, inputs=[], outputs=[], pool_size=10, generate=False,
                 training=0.8):

        self.average_fitness = 0
        self.prev_top_rule_set = None
        self.top_rule_set = None
        self.TRAINING = training
        self.POOL_SIZE = pool_size
        self.rule_sets = [None] * no_rules
        self.no_rules = no_rules

        # split data into training and validation set
        self.inputs = inputs[:(int(len(inputs) * training))]
        self.validate_inputs = inputs[(int(len(inputs) * training)):]
        self.validate_outputs = outputs[(int(len(outputs) * training)):]
        self.outputs = outputs[:(int(len(outputs) * training))]
        self.GENOME_LENGTH = no_rules * (len(inputs[0]) * 2 + 1)

        # self.MUTATION_RATE = 0.02
        self.MUTATION_RATE = 1 / self.GENOME_LENGTH  +0.007# self.MUTATION_RATE = 0.05
        # self.MUTATION_RATE = 1
        self.fitness_history = []  # used for graphing the top fitness history
        self.average_history = []  # used for graphing the average fitness history
        self.valid_history = [] # used for graphing and keeping validity results history
        self.generations = 1
        self.total_fitness = 0

        if generate:
            self.generate()
            self.evaluate_fitness(official=False)
            self.prev_top_rule_set = copy.deepcopy(self.top_rule_set)
            self.fitness_history.append(0)
            self.average_history.append(0)
            self.valid_history.append(0)
    # # tournament selection
    def start_tournament(self):
        # get index of best RUleset and make copy
        index = int(np.argmax([x.fitness for x in self.rule_sets]))
        self.prev_top_rule_set = copy.deepcopy(self.rule_sets[index])
        temp = []

        for b in range(self.POOL_SIZE):
            a = (self.rule_sets[np.random.randint(self.POOL_SIZE)])
            c = (self.rule_sets[np.random.randint(self.POOL_SIZE)])

            temp.append(copy.deepcopy(a if (a.fitness > c.fitness) else c))

        self.rule_sets.clear()
        self.rule_sets = temp

    # replace worst RUleset with previous best copy
    def replace_worst(self):
        index = int(np.argmin([x.fitness for x in self.rule_sets]))
        self.rule_sets[index] = copy.deepcopy(self.prev_top_rule_set)

    # one point cross over
    def cross_over(self):

        for index in range(0, self.POOL_SIZE, 2):
            cross_point = np.random.randint(self.GENOME_LENGTH)
            a = self.rule_sets[index]
            b = self.rule_sets[index + 1]
            a.genome[cross_point:], b.genome[cross_point:] = b.genome[cross_point:], a.genome[cross_point:]

    def mutate(self):
        for x in range(self.POOL_SIZE):
            self.rule_sets[x].mutate(mutation_rate=self.MUTATION_RATE)

    # self.MUTATION_RATE= 1

    # test vslidation data against top Ruleset so far.
    def validate(self):

        top =copy.deepcopy( self.top_rule_set if self.top_rule_set.fitness > self.prev_top_rule_set.fitness else self.prev_top_rule_set)

        top.evaluate_fitness(inputs=self.validate_inputs, outputs=self.validate_outputs)


        self.valid_history.append(top.fitness)


    # evaluate fitness of entire population
    def evaluate_fitness(self, official=True):
        # self.calc_rules()
# convert genome into list of rule objects
        self.total_fitness = 0
        for x in self.rule_sets:
            x.evaluate_fitness(inputs=self.inputs, outputs=self.outputs)
            self.total_fitness += x.fitness

        # get index of top ruleset and set top rule set to the one at that index
        top = int(np.argmax([x.fitness for x in self.rule_sets]))
        self.top_rule_set = self.rule_sets[top]
        # calculate average
        self.average_fitness = sum(x.fitness / self.POOL_SIZE for x in self.rule_sets)

        if official == True:
            self.generations += 1
            # only update validation result value none 10th generation as it gets update on the 10th somewhere else( valdation functions
            if (self.generations%10)!=0:
                self.valid_history.append(self.valid_history[-1])

            self.fitness_history.append(self.prev_top_rule_set.fitness if self.prev_top_rule_set.fitness > self.top_rule_set.fitness else self.top_rule_set.fitness)
            self.average_history.append(int(self.average_fitness))

    def calc_rules(self):
        for x in self.rule_sets:
            x.calc_rules()

    def generate(self):

        self.rule_sets[:] = (RuleSet(no_rules=self.no_rules, no_inputs=len(self.inputs[0] * 2), no_outputs=1) for x in
                             range(self.POOL_SIZE))

    def print_rules(self):

        for x in self.rule_sets:
            x.print_rule()

    def print(self):
        print("----------Population---------------")
        for x in self.rule_sets:
            x.print()

        if self.prev_top_rule_set.fitness> self.prev_top_rule_set.fitness :
            self.prev_top_rule_set.print()
        else:
            self.top_rule_set.print()
        print(f"Average Fitness : {self.average_fitness}   Top Fitness : {self.top_rule_set.fitness if self.top_rule_set.fitness> self.prev_top_rule_set.fitness else self.prev_top_rule_set.fitness}  Generation { self.generations} ")

    def graph_next_point(self):

        if hasattr(self, 'axarr') == False:

            self.f, self.axarr = pt.setup_common_subplots(1, 1, xlabel="Generation",
                                                          ylabel="Fitness Level",
                                                          title="Fitness Vs Generation Using ")

        self.axarr.set_ylim(0, len(self.inputs))
        pt.live_plot(self.fitness_history[-2], self.fitness_history[-1],
                     len(self.fitness_history) - 1, self.axarr)
        pt.live_plot(self.average_history[-2], self.average_history[-1],
                     len(self.average_history) - 1, self.axarr)
        pt.live_plot(self.valid_history[-2], self.valid_history[-1],
                     len(self.average_history) - 1, self.axarr)

    def graph_fitness_history(self):

        if hasattr(self, 'axarr1') == False:
            # print("dfgfdgfdgfdgfdgdfgdfgdfgdfgdfgdfgdfgdfgdfg")
            self.f1, self.axarr1 = pt.setup_common_subplots(1, 1, xlabel="Generation",
                                                            ylabel="Fitness Level",
                                                            title="Fitness Vs Generation Using ")

        self.axarr1.set_ylim(0, len(self.inputs))
        x = list(range(0, len(self.fitness_history)))
        print(f"{len(x)}   {len(self.fitness_history)}")
        self.axarr1.plot(x, self.fitness_history)
        self.axarr1.plot(x, self.average_history)


class RuleSet:

    def __init__(self, no_rules=10, no_inputs=5, no_outputs=1, label=1, generate=True):

        self.fitness = 0

        self.rules = no_rules * [None]

        self.no_rules = no_rules
        self.input_bits = no_inputs
        self.output_bits = no_outputs
        self.rule_bits = self.input_bits + self.output_bits
        self.genome_length = self.no_rules * self.rule_bits

        self.genome = [None] * self.genome_length
        self.rule_set_label = label

        if generate:
            self.generate()

    def generate(self):

        b = 0
        while b < self.genome_length:

            if (b + 1) % self.rule_bits == 0:
                self.genome[b] = np.random.randint(2)
                b += 1
            else:
                point = np.random.uniform() * 0.6 + 0.2

                lower = point - 0.2
                upper = point + 0.2
                self.genome[b] = np.random.uniform()
                self.genome[b + 1] = np.random.uniform()

                b += 2

    def evaluate_fitness(self, inputs, outputs, prints=False):

        sum_ = 0

        for x in range(len(inputs)):
            solved_output = self.look_up_rule(inputs[x], prints=prints)

            if solved_output == None:
                fitness = 0
            else:
                fitness = 1 if (solved_output == outputs[x]) else 0

            sum_ += fitness

        self.fitness = sum_

    #  look for rule in rule list  that corresponds with data input
    def look_up_rule(self, input, prints=False):

        for x in self.rules:
            correct = 0

            for v in range(len(x.cmd)):

                # print(f"x.cmd[v]{x.cmd[v][0]}  {x.cmd[v][1]}     data {input[v]}   {(x.cmd[v][0] > input[v]) or (x.cmd[v][1] < input[v])})")
                if ((x.cmd[v][0] > input[v]) or (x.cmd[v][1] < input[v]) and (x.cmd[v][0] < x.cmd[v][1])):

                    break
                else:
                    correct += 1

            if (correct == len(x.cmd)):
                # print("found rule")
                return x.output

        # print("No rule ")
        return None

    # mutate specific genome
    def mutate(self, mutation_rate=0.1):

        for i in range(len(self.genome)):
            if np.random.uniform() < mutation_rate:
                if ((i + 1) % self.rule_bits) == 0:
                    self.genome[i] = abs(self.genome[i] - 1)
                else:
                    randN = np.random.uniform() * 0.2 - 0.1
                    # print(f" rand {randN}")
                    if self.genome[i] + randN > 1:
                        self.genome[i] = self.genome[i] - randN
                    elif self.genome[i] + randN < 0:
                        self.genome[i] = self.genome[i] - randN
                    else:
                        # print(f"before : {self.genome[i]}")
                        self.genome[i] = self.genome[i] + randN
                        # print(f"After : {self.genome[i]}")

                    if (self.genome[i] < 0 or self.genome[i] > 1):
                        print(self.genome[i])

                        a = input("dgdfg")

        # comment out if wanting to use wild-ranges
        self.auto_correct_ranges()


    # use when not using wild-ranges
    def auto_correct_ranges(self):

        b = 0
        for i in range(self.no_rules):

            for j in range(0, self.input_bits, 2):

                if (self.genome[b] > self.genome[b + 1]):
                    self.genome[b], self.genome[b + 1] = self.genome[b + 1], self.genome[b]
                b += 2

            b += 1

    # convert genome to list of rules
    def calc_rules(self):
        self.rules = []

        j = 0
        for i in range((self.no_rules)):

            cmd = []
            for b in range(0, self.input_bits, 2):
                ranges = self.genome[j:j + 2]

                cmd.append(copy.deepcopy(ranges))
                j += 2

            out = self.genome[j]
            j += 1
            rule = RuleSet.Rule(cmd=cmd, output=out)
            self.rules.append(rule)

    def print(self):
        print(f"{self.genome}  Fitness : {self.fitness}")

    def print_rule(self):
        for x in self.rules:
            print("---------------------------")
            x.print()

        print(f"Fitness :{self.fitness}")

    class Rule:

        def __init__(self, cmd=[], output=None):
            self.cmd = cmd
            self.output = output

        def print(self):
            print(f"{self.cmd} {self.output}")
